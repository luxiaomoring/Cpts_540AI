// Agent.cc
//cpts_540 hw2
//author: Lu Xiao  11624097

#include <iostream>
#include "Agent.h"

using namespace std;

Agent::Agent ()
{
}

Agent::~Agent ()
{
    
}

void Agent::Initialize ()
{
    worldState.worldSize = 4;
    worldState.agentLocation.X=1;
    worldState.agentLocation.Y=1;
    worldState.agentOrientation = RIGHT;
    worldState.agentHasArrow = true;
    worldState.agentHasGold = false;
    worldState.wumpusAlive = true;

    
}


Action Agent::Process (Percept& percept)
{
    Action action;
    if (percept.Glitter)
    {
        actions.push_back(GRAB);//If the agent observes the Glitter percept, it should execute the GRAB action.
    } else if ((percept.Stench) && (worldState.agentHasArrow)) {
        if(action==TURNLEFT) {
            actions.push_back(TURNLEFT);
            actions.push_back(SHOOT);
            
        }
        if(action==TURNRIGHT){
            actions.push_back(TURNRIGHT);
            actions.push_back(SHOOT);
            
        }
        else{
                actions.push_back(SHOOT);
            }
        }
        
        //actions.push_back(SHOOT);//If the agent observes the Stench percept, and it has an arrow, then it should execute
        // we need to figure out that when our agent face to W  then the arrow can work. Sometimes we need turn to face to W then SHOOT it.
    if (actions.empty())
    {
        if(!percept.Bump)
        {
            actions.push_back(GOFORWARD);// Otherwise, the agent should execute the GOFORWARD action.
        }
        else
        {
            actions.push_back(TURNLEFT);
        }
        
    }
    action = actions.front();
    actions.pop_front();
    ExecuteAction (action);
    return action;
    
    
}


void Agent::ExecuteAction (Action action)
{
    if (action == GOFORWARD)
    {   actions.push_back(GOFORWARD);
        actions.clear();
    } else if (action == TURNLEFT) {
        if (worldState.agentOrientation == RIGHT)
        {
            worldState.agentOrientation = UP;
        } else if (worldState.agentOrientation == UP)
        {
            worldState.agentOrientation = LEFT;
        } else if (worldState.agentOrientation == LEFT)
        {
            worldState.agentOrientation = DOWN;
        } else if (worldState.agentOrientation == DOWN)
        {
            worldState.agentOrientation = RIGHT;
        }
        
    } else if (action == TURNRIGHT)
        {
            if (worldState.agentOrientation == RIGHT)
            {
                worldState.agentOrientation = DOWN;
            } else if (worldState.agentOrientation == UP)
            {
                worldState.agentOrientation = RIGHT;
            } else if (worldState.agentOrientation == LEFT)
            {
                worldState.agentOrientation = UP;
            } else if (worldState.agentOrientation == DOWN)
            {
                worldState.agentOrientation = LEFT;
            }

    }else if (action == GRAB) {
        worldState.agentHasGold = true;
    } else if (action == SHOOT) {
        worldState.agentHasArrow = false;
    } else if (action == CLIMB) {
        actions.push_back(CLIMB);
    }
}


void Agent::GameOver (int score)
{
    
}
